/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientwordsearch_ammar617;

import clientwordsearch_ammar617.wordSearchClient;
import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class ClientWordSearch_ammar617 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("--- Ammar 617 ---");
        Scanner sc = new Scanner(System.in);
        clientwordsearch_ammar617.wordSearchClient obj = new wordSearchClient();
        String ans = obj.searchDataMethod("find me string");
        System.out.println("Result: " + ans);
        
    }
    
}
