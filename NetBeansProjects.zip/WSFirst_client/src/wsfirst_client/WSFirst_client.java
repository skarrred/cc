/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsfirst_client;

/**
 *
 * @author ACER
 */
public class WSFirst_client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int n1 = 10;
        int n2 = 20;
        double r1 = add(n1, n2);
        double r2 = sub(n1, n2);
        double r3 = div(n1, n2);
        double r4 = mul(n1, n2);
        System.out.println(r1);
        System.out.println(r2);
        System.out.println(r3);
        System.out.println(r4);
    }

    private static double add(int n1, int n2) {
        mypackagecalws.CalciiWS_Service service = new mypackagecalws.CalciiWS_Service();
        mypackagecalws.CalciiWS port = service.getCalciiWSPort();
        return port.add(n1, n2);
    }

    private static double div(int n1, int n2) {
        mypackagecalws.CalciiWS_Service service = new mypackagecalws.CalciiWS_Service();
        mypackagecalws.CalciiWS port = service.getCalciiWSPort();
        return port.div(n1, n2);
    }

    private static double mul(int n1, int n2) {
        mypackagecalws.CalciiWS_Service service = new mypackagecalws.CalciiWS_Service();
        mypackagecalws.CalciiWS port = service.getCalciiWSPort();
        return port.mul(n1, n2);
    }

    private static double sub(int n1, int n2) {
        mypackagecalws.CalciiWS_Service service = new mypackagecalws.CalciiWS_Service();
        mypackagecalws.CalciiWS port = service.getCalciiWSPort();
        return port.sub(n1, n2);
    }
    
}
