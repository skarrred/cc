/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4_restfulclient_ammar617;

/**
 *
 * @author ACER
 */
public class P4_restfulClient_ammar617 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        restfulClientPackage.restFulClient obj = new restfulClientPackage.restFulClient();
        System.out.println(obj.ToUC("to upper"));
        System.out.println(obj.ToLC("to lower"));

    }
    
}
