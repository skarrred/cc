/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackagecalws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *

 */
@WebService(serviceName = "CalciiWS")
public class CalciiWS {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "add")
    public double add(@WebParam(name = "n1") int n1, @WebParam(name = "n2") int n2) {
        //TODO write your implementation code here:
        return (n1+n2);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sub")
    public double sub(@WebParam(name = "n1") int n1, @WebParam(name = "n2") int n2) {
        //TODO write your implementation code here:
        return (n1-n2);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "mul")
    public double mul(@WebParam(name = "n1") int n1, @WebParam(name = "n2") int n2) {
        //TODO write your implementation code here:
        return (n1*n2);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "div")
    public double div(@WebParam(name = "n1") int n1, @WebParam(name = "n2") int n2) {
        //TODO write your implementation code here:
        return (n1/n2);
    }

    /**
     * This is a sample web service operation
     */
    
}
