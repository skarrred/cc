/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypackage;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author zeena
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {

    /**
     * Web service operation
     */
     @WebMethod(operationName = "R2D")
    public double R2D(@WebParam(name = "rs") double rs) {
        //TODO write your implementation code here:
        double ans = rs / 65;
        return ans;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "D2R")
    public double D2R(@WebParam(name = "dollar") double dollar) {
        //TODO write your implementation code here:
        double ans = dollar * 65;
        return ans;
    }

    /**
     * This is a sample web service operation
     */
    
    
}
