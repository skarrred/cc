/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addPackage;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author zeena
 */
@WebService(serviceName = "AddService")
public class AddService {

    /**
     * This is a sample web service operation
     */
   @WebMethod(operationName = "addThreeNumbers")
public int addThreeNumbers(@WebParam(name = "num1") int num1, @WebParam(name = "num2") int num2, @WebParam(name = "num3") int num3) {
    return num1 + num2 + num3;
}
}