/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypac;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author zeena
 */
@WebService(serviceName = "WSCCu")
public class WSCCu {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "R2D")
    public double R2D(@WebParam(name = "rupees") double rupees) {
        double ans = rupees /65;//TODO write your implementation code here:
        return ans;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "D2R")
    public double D2R(@WebParam(name = "dollar") double dollar) {
        double ans = dollar * 65;
        //TODO write your implementation code here:
        return ans;
    }
}
