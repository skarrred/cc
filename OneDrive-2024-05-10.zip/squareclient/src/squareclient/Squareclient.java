package squareclient;

/**
 *
 * @author zeena
 */
public class Squareclient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int number = 5; // Example number
        int square = calculateSquare(number);
        System.out.println("Square of " + number + " is: " + square);
    }

    private static int calculateSquare(int number) {
        try {
            mypac.SquareService_Service service = new mypac.SquareService_Service();
            mypac.SquareService port = service.getSquareServicePort();
            return port.calculateSquare(number);
        } catch (Exception ex) {
            // Handle exceptions appropriately, e.g., logging or displaying an error message
            ex.printStackTrace();
            return -1; // or throw exception
        }
    }
}
